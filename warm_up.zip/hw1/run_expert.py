#!/usr/bin/env python3

"""
Code to load an expert policy and generate roll-out data for behavioral cloning.
Example usage:
    python run_expert.py experts/Humanoid-v1.pkl Humanoid-v1 --render \
            --num_rollouts 20

Author of this script and included expert policies: Jonathan Ho (hoj@openai.com)
"""

import pickle
import tensorflow as tf
import numpy as np
import tf_util
import gym
from gym import wrappers
import load_policy
import matplotlib.pyplot as plt

def max_pool_2x2(x):
  """max_pool_2x2 downsamples a feature map by 2X."""
  return tf.nn.max_pool(x, ksize=[1, 2, 2, 1],
                        strides=[1, 2, 2, 1], padding='SAME')
  
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('expert_policy_file', type=str, default='experts/Hopper-v1.pkl')
    parser.add_argument('envname', type=str, default='Hopper-v1')
    parser.add_argument('--render', action='store_true')
    parser.add_argument("--max_timesteps", type=int)
    parser.add_argument('--num_rollouts', type=int, default=20,
                        help='Number of expert roll outs')
    args = parser.parse_args()

    print('loading and building expert policy')
    policy_fn = load_policy.load_policy(args.expert_policy_file)
    print('loaded and built')


    np.random.seed(0)

    expert_data = {}

    sess = tf.Session()
    with sess:
        tf_util.initialize()

        import gym
        env = gym.make(args.envname)
        max_steps = args.max_timesteps or env.spec.timestep_limit

        returns = []
        observations = []
        actions = []
        
        #### Model to train on expert data

        # Create the model
        x = tf.placeholder(tf.float32, [None, env.observation_space.shape[0]])
        
        W_1_1 = tf.Variable(tf.truncated_normal([env.observation_space.shape[0], 30], stddev=0.1))
        b_1_1 = tf.Variable(tf.constant(0.1, shape=[30]))
        h_1_1 = tf.nn.tanh(tf.matmul(x, W_1_1) + b_1_1)
        
        W_1 = tf.Variable(tf.truncated_normal([30, 50], stddev=0.1))
        b_1 = tf.Variable(tf.constant(0.1, shape=[50]))
        h_1 = tf.nn.tanh(tf.matmul(h_1_1, W_1) + b_1)
        
        W_2 = tf.Variable(tf.truncated_normal([50, 100], stddev=0.1))
        b_2 = tf.Variable(tf.constant(0.1, shape=[100]))
        h_2 = tf.nn.tanh(tf.matmul(h_1, W_2) + b_2)
        
        W_21 = tf.Variable(tf.truncated_normal([100, 200], stddev=0.1))
        b_21 = tf.Variable(tf.constant(0.1, shape=[200]))
        h_21 = tf.nn.tanh(tf.matmul(h_2, W_21) + b_21)
        
        W_22 = tf.Variable(tf.truncated_normal([200, 100], stddev=0.1))
        b_22 = tf.Variable(tf.constant(0.1, shape=[100]))
        h_22 = tf.nn.tanh(tf.matmul(h_21, W_22) + b_22)

        W_23 = tf.Variable(tf.truncated_normal([100, 50], stddev=0.1))
        b_23 = tf.Variable(tf.constant(0.1, shape=[50]))
        h_23 = tf.nn.tanh(tf.matmul(h_22, W_23) + b_23)
        
        W_3 = tf.Variable(tf.truncated_normal([50, 20], stddev=0.1))
        b_3 = tf.Variable(tf.constant(0.1, shape=[20]))
        h_3 = tf.nn.tanh(tf.matmul(h_23, W_3) + b_3)
        
        W_4 = tf.Variable(tf.truncated_normal([20, 10], stddev=0.1))
        b_4 = tf.Variable(tf.constant(0.1, shape=[10]))
        h_4 = tf.nn.tanh(tf.matmul(h_3, W_4) + b_4)
        
        W_5 = tf.Variable(tf.truncated_normal([10, 5], stddev=0.1))
        b_5 = tf.Variable(tf.constant(0.1, shape=[5]))
        h_5 = tf.nn.tanh(tf.matmul(h_4, W_5) + b_5)
        
        W = tf.Variable(tf.truncated_normal([5, env.action_space.shape[0]], stddev=0.1))
        b = tf.Variable(tf.constant(0.1, shape=[env.action_space.shape[0]]))
        y = tf.matmul(h_5, W) + b
        
        y_ = tf.placeholder(tf.float32, [None, env.action_space.shape[0]])
        cross_entropy = tf.reduce_mean(tf.nn.l2_loss(y-y_))


        train_step = tf.train.AdamOptimizer(1e-3).minimize(cross_entropy)

    
        for i in range(args.num_rollouts):
            print('iter', i)
            obs = env.reset()
            done = False
            totalr = 0.
            steps = 0
            while not done:
                action = policy_fn(obs[None,:])
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = env.step(action)
                totalr += r
                steps += 1
                if args.render:
                    env.render()
                if steps % 100 == 0: print("%i/%i"%(steps, max_steps))
                if steps >= max_steps:
                    break
            returns.append(totalr)

        print('returns', returns)
        print('mean return', np.mean(returns))
        print('std of return', np.std(returns))

        expert_data = {'observations': np.array(observations),
                       'actions': np.array(actions)}


        
        losses = []
        tf.global_variables_initializer().run()
        num_data = int(expert_data['observations'].size/env.observation_space.shape[0])
        for i in range(20000):
            ind = np.arange(num_data)
            np.random.shuffle(ind)
            batch_xs = expert_data['observations'][ind].reshape(num_data,env.observation_space.shape[0])
            batch_ys = expert_data['actions'][ind].reshape(num_data,env.action_space.shape[0])

            t, loss = sess.run([train_step, cross_entropy], feed_dict={x: batch_xs, y_: batch_ys})
            losses.append(loss)
            print('step %d, loss %g' % (i, loss))

        plt.plot(np.arange(len(losses)), losses)
        plt.title('l2 Training Loss vs Training Iterations')
        plt.ylabel('l2 Training Loss')
        plt.xlabel('Training Iterations')
        plt.show()


        # Now run the newly trained model
        
        returns = []
        observations = []
        actions = []
        #env = wrappers.Monitor(env, '/home/vhan/Documents/cs294-112/homework/hw1/tmp/vids/test', force=True)
        for i in range(args.num_rollouts):
            print('iter', i)
            obs = env.reset()
            done = False
            totalr = 0.
            steps = 0
            while not done:
                action = sess.run(y, feed_dict={x: obs.reshape(1,env.observation_space.shape[0])})
                observations.append(obs)
                actions.append(action)
                obs, r, done, _ = env.step(action)
                totalr += r
                steps += 1
                if args.render:
                    env.render()
                if steps % 100 == 0: print("%i/%i"%(steps, max_steps))
                if steps >= max_steps:
                    break
            returns.append(totalr)

        print('returns', returns)
        print('mean return', np.mean(returns))
        print('std of return', np.std(returns))


if __name__ == '__main__':
    main()
